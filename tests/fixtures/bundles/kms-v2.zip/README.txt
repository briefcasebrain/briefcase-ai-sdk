BRIEFCASE EVIDENCE BUNDLE (format briefcase-bundle, version 2)
============================================================

Created 2026-11-22T05:45:08.515634Z. A sealed routing decision with the policy in effect as of None and
the evidence records it cited: 1 record(s) in total.

HOW TO CHECK IT

    pip install briefcase-ai
    briefcase bundle verify THIS_FILE.zip --key kms:arn:aws:kms:us-east-1:111122223333:key/00000000-0000-4000-8000-000000000002 --kms

Ed25519 checks need no network. Compare each key id with the one the record keeper
published through another channel. AWS KMS signatures are checked by calling KMS
(--kms) with the key id you were given; without that they are reported unchecked.

WHAT A PASSING CHECK PROVES

- No file in the bundle changed after it was made: manifest.json lists the SHA-256 of
  every file and content_hash covers the manifest.
- The bundle was sealed by: AWS KMS key arn:aws:kms:us-east-1:111122223333:key/00000000-0000-4000-8000-000000000002 (RSASSA_PSS_SHA_256).

WHAT IT DOES NOT PROVE

- That the log or the evidence is complete: records outside the selection, or evidence a
  decision relied on but did not cite, are not here. A log could have been cut or rebuilt
  before a checkpoint was made unless that checkpoint was stored where the record keeper
  cannot change it (a WORM bucket, an email to the auditor, a ticket).
- That the records are true; only that they did not change after they were sealed.
- Anything about content that was redacted or hashed at capture time.
- Who controls the signing key. A key holder could have signed a rewritten history.

FILES

manifest.json     format, version, hash scheme, context, counts, file hashes, content_hash, signatures
records.jsonl     {role, record, entry?, proof?} per line (roles: record, decision, policy, evidence)
checkpoints.json  chain checkpoints the proofs refer to, with signatures
keys.json         Ed25519 public keys (RFC 8037 JWK) by key id (RFC 7638 thumbprint)

The format is specified in docs/features/audit-bundle.md of the briefcase-ai SDK.
