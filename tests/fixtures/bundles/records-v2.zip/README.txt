BRIEFCASE EVIDENCE BUNDLE (format briefcase-bundle, version 2)
============================================================

Created 2026-11-22T05:45:08.467674Z from evidence.db (6 entries in its chain).
Selection: every record in the source.
Contents: 6 record(s), 2 checkpoint(s).

HOW TO CHECK IT

    pip install briefcase-ai
    briefcase bundle verify THIS_FILE.zip --key d481b6b4c1fb276c1b2599ce7fc2c9cd08ad29fecb32fa00125b2e0cc54ce786

Ed25519 checks need no network. Compare each key id with the one the record keeper
published through another channel. AWS KMS signatures are checked by calling KMS
(--kms) with the key id you were given; without that they are reported unchecked.

WHAT A PASSING CHECK PROVES

- No file in the bundle changed after it was made: manifest.json lists the SHA-256 of
  every file and content_hash covers the manifest.
- The bundle was sealed by: Ed25519 key d481b6b4c1fb276c1b2599ce7fc2c9cd08ad29fecb32fa00125b2e0cc54ce786.
- Each chained record is byte-for-byte the record written to the hash chain, and was in
  the log when the checkpoint named in its proof was made (Merkle inclusion proof).
- Those checkpoints were signed by Ed25519 key(s) d481b6b4c1fb276c.
- 1 checkpoint(s) were made when this bundle was created (origin: bundle) because the
  store had not yet checkpointed the newest records; they attest what the bundle creator saw.

WHAT IT DOES NOT PROVE

- That the log or the evidence is complete: records outside the selection, or evidence a
  decision relied on but did not cite, are not here. A log could have been cut or rebuilt
  before a checkpoint was made unless that checkpoint was stored where the record keeper
  cannot change it (a WORM bucket, an email to the auditor, a ticket).
- That the records are true; only that they did not change after they were sealed.
- Anything about content that was redacted or hashed at capture time.
- Who controls the signing key. A key holder could have signed a rewritten history.

FILES

manifest.json     format, version, hash scheme, context, counts, file hashes, content_hash, signatures
records.jsonl     {role, record, entry?, proof?} per line (roles: record, decision, policy, evidence)
checkpoints.json  chain checkpoints the proofs refer to, with signatures
keys.json         Ed25519 public keys (RFC 8037 JWK) by key id (RFC 7638 thumbprint)

The format is specified in docs/features/audit-bundle.md of the briefcase-ai SDK.
